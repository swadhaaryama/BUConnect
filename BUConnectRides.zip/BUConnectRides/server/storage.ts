import { 
  users, type User, type InsertUser,
  rides, type Ride, type InsertRide,
  bookings, type Booking, type InsertBooking,
  messages, type Message, type InsertMessage
} from "@shared/schema";

import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

// Modify the interface with any CRUD methods you might need
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  
  // Ride methods
  createRide(ride: InsertRide): Promise<Ride>;
  getRide(id: number): Promise<Ride | undefined>;
  getRidesByDriver(driverId: number): Promise<Ride[]>;
  getAvailableRides(): Promise<Ride[]>;
  updateRideStatus(id: number, status: string): Promise<Ride | undefined>;
  updateRideSeats(id: number, availableSeats: number): Promise<Ride | undefined>;
  
  // Booking methods
  createBooking(booking: InsertBooking): Promise<Booking>;
  getBooking(id: number): Promise<Booking | undefined>;
  getBookingsByPassenger(passengerId: number): Promise<Booking[]>;
  getBookingsByRide(rideId: number): Promise<Booking[]>;
  updateBookingStatus(id: number, status: string): Promise<Booking | undefined>;
  
  // Message methods
  createMessage(message: InsertMessage): Promise<Message>;
  getMessagesByUser(userId: number): Promise<Message[]>;
  getConversation(user1Id: number, user2Id: number): Promise<Message[]>;
  markMessageAsRead(id: number): Promise<Message | undefined>;
  
  // Session store
  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private rides: Map<number, Ride>;
  private bookings: Map<number, Booking>;
  private messages: Map<number, Message>;
  sessionStore: session.SessionStore;
  
  private userIdCounter: number;
  private rideIdCounter: number;
  private bookingIdCounter: number;
  private messageIdCounter: number;

  constructor() {
    this.users = new Map();
    this.rides = new Map();
    this.bookings = new Map();
    this.messages = new Map();
    
    this.userIdCounter = 1;
    this.rideIdCounter = 1;
    this.bookingIdCounter = 1;
    this.messageIdCounter = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const now = new Date();
    const user: User = { 
      ...insertUser, 
      id, 
      rating: 0,
      ridesTaken: 0,
      ridesOffered: 0,
      co2Saved: 0,
      createdAt: now
    };
    this.users.set(id, user);
    return user;
  }
  
  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Ride methods
  async createRide(insertRide: InsertRide): Promise<Ride> {
    const id = this.rideIdCounter++;
    const now = new Date();
    const ride: Ride = {
      ...insertRide,
      id,
      status: "active",
      createdAt: now
    };
    this.rides.set(id, ride);
    
    // Update driver's rides offered count
    const driver = await this.getUser(ride.driverId);
    if (driver) {
      await this.updateUser(driver.id, {
        ridesOffered: (driver.ridesOffered || 0) + 1
      });
    }
    
    return ride;
  }
  
  async getRide(id: number): Promise<Ride | undefined> {
    return this.rides.get(id);
  }
  
  async getRidesByDriver(driverId: number): Promise<Ride[]> {
    return Array.from(this.rides.values()).filter(
      (ride) => ride.driverId === driverId
    );
  }
  
  async getAvailableRides(): Promise<Ride[]> {
    return Array.from(this.rides.values()).filter(
      (ride) => ride.status === "active" && ride.availableSeats > 0
    );
  }
  
  async updateRideStatus(id: number, status: string): Promise<Ride | undefined> {
    const ride = await this.getRide(id);
    if (!ride) return undefined;
    
    const updatedRide = { ...ride, status };
    this.rides.set(id, updatedRide);
    return updatedRide;
  }
  
  async updateRideSeats(id: number, availableSeats: number): Promise<Ride | undefined> {
    const ride = await this.getRide(id);
    if (!ride) return undefined;
    
    const updatedRide = { ...ride, availableSeats };
    this.rides.set(id, updatedRide);
    return updatedRide;
  }

  // Booking methods
  async createBooking(insertBooking: InsertBooking): Promise<Booking> {
    const id = this.bookingIdCounter++;
    const now = new Date();
    const booking: Booking = {
      ...insertBooking,
      id,
      status: "confirmed",
      createdAt: now
    };
    this.bookings.set(id, booking);
    
    // Update ride's available seats
    const ride = await this.getRide(booking.rideId);
    if (ride && ride.availableSeats > 0) {
      await this.updateRideSeats(ride.id, ride.availableSeats - 1);
    }
    
    // Update passenger's rides taken count and CO2 saved
    const passenger = await this.getUser(booking.passengerId);
    if (passenger) {
      await this.updateUser(passenger.id, {
        ridesTaken: (passenger.ridesTaken || 0) + 1,
        co2Saved: (passenger.co2Saved || 0) + 2 // 2kg per shared ride as a simple calculation
      });
    }
    
    return booking;
  }
  
  async getBooking(id: number): Promise<Booking | undefined> {
    return this.bookings.get(id);
  }
  
  async getBookingsByPassenger(passengerId: number): Promise<Booking[]> {
    return Array.from(this.bookings.values()).filter(
      (booking) => booking.passengerId === passengerId
    );
  }
  
  async getBookingsByRide(rideId: number): Promise<Booking[]> {
    return Array.from(this.bookings.values()).filter(
      (booking) => booking.rideId === rideId
    );
  }
  
  async updateBookingStatus(id: number, status: string): Promise<Booking | undefined> {
    const booking = await this.getBooking(id);
    if (!booking) return undefined;
    
    const updatedBooking = { ...booking, status };
    this.bookings.set(id, updatedBooking);
    
    // If cancelling, update ride's available seats
    if (status === "cancelled" && booking.status !== "cancelled") {
      const ride = await this.getRide(booking.rideId);
      if (ride) {
        await this.updateRideSeats(ride.id, ride.availableSeats + 1);
      }
    }
    
    return updatedBooking;
  }

  // Message methods
  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = this.messageIdCounter++;
    const now = new Date();
    const message: Message = {
      ...insertMessage,
      id,
      read: false,
      createdAt: now
    };
    this.messages.set(id, message);
    return message;
  }
  
  async getMessagesByUser(userId: number): Promise<Message[]> {
    return Array.from(this.messages.values()).filter(
      (message) => message.senderId === userId || message.receiverId === userId
    );
  }
  
  async getConversation(user1Id: number, user2Id: number): Promise<Message[]> {
    return Array.from(this.messages.values()).filter(
      (message) => 
        (message.senderId === user1Id && message.receiverId === user2Id) ||
        (message.senderId === user2Id && message.receiverId === user1Id)
    ).sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
  }
  
  async markMessageAsRead(id: number): Promise<Message | undefined> {
    const message = this.messages.get(id);
    if (!message) return undefined;
    
    const updatedMessage = { ...message, read: true };
    this.messages.set(id, updatedMessage);
    return updatedMessage;
  }
}

export const storage = new MemStorage();
