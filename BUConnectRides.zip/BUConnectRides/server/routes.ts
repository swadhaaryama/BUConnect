import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { insertRideSchema, insertBookingSchema, insertMessageSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);

  // API routes - all prefixed with /api
  
  // Rides routes
  app.get("/api/rides", async (req, res) => {
    try {
      const rides = await storage.getAvailableRides();
      res.json(rides);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch rides" });
    }
  });
  
  app.post("/api/rides", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const validatedRide = insertRideSchema.parse({
        ...req.body,
        driverId: req.user.id,
      });
      
      const ride = await storage.createRide(validatedRide);
      res.status(201).json(ride);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid ride data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create ride" });
    }
  });
  
  app.get("/api/rides/driver", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const rides = await storage.getRidesByDriver(req.user.id);
      res.json(rides);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch driver rides" });
    }
  });
  
  app.get("/api/rides/:id", async (req, res) => {
    try {
      const rideId = parseInt(req.params.id);
      const ride = await storage.getRide(rideId);
      
      if (!ride) {
        return res.status(404).json({ message: "Ride not found" });
      }
      
      res.json(ride);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch ride" });
    }
  });
  
  // Bookings routes
  app.post("/api/bookings", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const validatedBooking = insertBookingSchema.parse({
        ...req.body,
        passengerId: req.user.id,
      });
      
      // Check if ride exists and has available seats
      const ride = await storage.getRide(validatedBooking.rideId);
      if (!ride) {
        return res.status(404).json({ message: "Ride not found" });
      }
      
      if (ride.availableSeats <= 0) {
        return res.status(400).json({ message: "No seats available on this ride" });
      }
      
      if (ride.driverId === req.user.id) {
        return res.status(400).json({ message: "You cannot book your own ride" });
      }
      
      const booking = await storage.createBooking(validatedBooking);
      res.status(201).json(booking);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid booking data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create booking" });
    }
  });
  
  app.get("/api/bookings/passenger", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const bookings = await storage.getBookingsByPassenger(req.user.id);
      
      // Get ride details for each booking
      const bookingsWithRides = await Promise.all(
        bookings.map(async (booking) => {
          const ride = await storage.getRide(booking.rideId);
          return { ...booking, ride };
        })
      );
      
      res.json(bookingsWithRides);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch bookings" });
    }
  });
  
  app.patch("/api/bookings/:id/cancel", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const bookingId = parseInt(req.params.id);
      const booking = await storage.getBooking(bookingId);
      
      if (!booking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      
      if (booking.passengerId !== req.user.id) {
        return res.status(403).json({ message: "Unauthorized to cancel this booking" });
      }
      
      const updatedBooking = await storage.updateBookingStatus(bookingId, "cancelled");
      res.json(updatedBooking);
    } catch (error) {
      res.status(500).json({ message: "Failed to cancel booking" });
    }
  });
  
  // Messages routes
  app.post("/api/messages", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const validatedMessage = insertMessageSchema.parse({
        ...req.body,
        senderId: req.user.id,
      });
      
      // Check if receiver exists
      const receiver = await storage.getUser(validatedMessage.receiverId);
      if (!receiver) {
        return res.status(404).json({ message: "Receiver not found" });
      }
      
      const message = await storage.createMessage(validatedMessage);
      res.status(201).json(message);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid message data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to send message" });
    }
  });
  
  app.get("/api/messages/conversations", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const messages = await storage.getMessagesByUser(req.user.id);
      
      // Get unique conversation partners
      const conversationPartners = new Set<number>();
      messages.forEach((message) => {
        if (message.senderId === req.user.id) {
          conversationPartners.add(message.receiverId);
        } else if (message.receiverId === req.user.id) {
          conversationPartners.add(message.senderId);
        }
      });
      
      // Get latest message and user details for each conversation
      const conversations = await Promise.all(
        Array.from(conversationPartners).map(async (partnerId) => {
          const conversationMessages = await storage.getConversation(req.user.id, partnerId);
          const latestMessage = conversationMessages[conversationMessages.length - 1];
          const partner = await storage.getUser(partnerId);
          
          // Count unread messages
          const unreadCount = conversationMessages.filter(
            msg => msg.receiverId === req.user.id && !msg.read
          ).length;
          
          return {
            partnerId,
            partnerName: partner?.name,
            partnerPicture: partner?.profilePicture,
            latestMessage,
            unreadCount,
          };
        })
      );
      
      res.json(conversations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch conversations" });
    }
  });
  
  app.get("/api/messages/:partnerId", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const partnerId = parseInt(req.params.partnerId);
      const messages = await storage.getConversation(req.user.id, partnerId);
      
      // Mark received messages as read
      await Promise.all(
        messages
          .filter(msg => msg.receiverId === req.user.id && !msg.read)
          .map(msg => storage.markMessageAsRead(msg.id))
      );
      
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });
  
  // User routes
  app.patch("/api/user", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      // Don't allow changing username or password via this route
      const { username, password, id, ...updateData } = req.body;
      
      const updatedUser = await storage.updateUser(req.user.id, updateData);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Remove password from response
      const userResponse = { ...updatedUser };
      delete userResponse.password;
      
      res.json(userResponse);
    } catch (error) {
      res.status(500).json({ message: "Failed to update user" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
