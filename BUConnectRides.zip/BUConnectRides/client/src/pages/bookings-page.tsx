import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Layout from "@/components/layout";
import RideCard from "@/components/ride-card";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";

type BookingWithRide = {
  id: number;
  rideId: number;
  passengerId: number;
  status: string;
  createdAt: string;
  ride: {
    id: number;
    driverId: number;
    from: string;
    to: string;
    departureDate: string;
    departureTime: string;
    availableSeats: number;
    price: number;
    notes?: string;
    status: string;
    createdAt: string;
  };
};

export default function BookingsPage() {
  const [location, navigate] = useLocation();
  const { toast } = useToast();
  const [filter, setFilter] = useState<"upcoming" | "past">("upcoming");
  
  // Fetch user's bookings
  const { data: bookings, isLoading, error } = useQuery<BookingWithRide[]>({
    queryKey: ["/api/bookings/passenger"],
  });
  
  // Filter bookings based on status
  const filteredBookings = bookings?.filter(booking => {
    if (filter === "upcoming") {
      return booking.status === "confirmed";
    } else {
      return booking.status === "completed" || booking.status === "cancelled";
    }
  });

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold text-gray-900">Your Bookings</h2>
          <div className="flex space-x-2">
            <Button
              variant={filter === "upcoming" ? "default" : "outline"}
              size="sm"
              className="px-3 py-1.5"
              onClick={() => setFilter("upcoming")}
            >
              Upcoming
            </Button>
            <Button
              variant={filter === "past" ? "default" : "outline"}
              size="sm"
              className="px-3 py-1.5"
              onClick={() => setFilter("past")}
            >
              Past
            </Button>
          </div>
        </div>
        
        {isLoading ? (
          <div className="flex justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : error ? (
          <div className="text-center py-8">
            <p className="text-red-500">Error loading bookings. Please try again.</p>
            <Button
              variant="outline"
              className="mt-2"
              onClick={() => window.location.reload()}
            >
              Refresh
            </Button>
          </div>
        ) : filteredBookings && filteredBookings.length > 0 ? (
          filteredBookings.map((booking) => (
            <RideCard
              key={booking.id}
              ride={booking.ride}
              isBooking={true}
              status={booking.status}
              bookingId={booking.id}
              onChatClick={() => {
                toast({
                  title: "Chat feature",
                  description: "Chat feature will be available soon.",
                });
              }}
              onRateClick={() => {
                toast({
                  title: "Rating feature",
                  description: "Rating feature will be available soon.",
                });
              }}
            />
          ))
        ) : (
          <div className="text-center py-8">
            <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-gray-100">
              <i className="fas fa-calendar-times text-gray-500"></i>
            </div>
            <h3 className="mt-2 text-sm font-medium text-gray-900">No bookings</h3>
            <p className="mt-1 text-sm text-gray-500">
              You don't have any {filter === "upcoming" ? "upcoming" : "past"} bookings.
            </p>
            <div className="mt-6">
              <Button
                type="button"
                onClick={() => navigate("/")}
              >
                <i className="fas fa-search mr-1"></i>
                Find a ride
              </Button>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}
