import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Ride } from "@shared/schema";
import Layout from "@/components/layout";
import RideCard from "@/components/ride-card";
import MapView from "@/components/map-view";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";

export default function HomePage() {
  const [location, navigate] = useLocation();
  const { toast } = useToast();
  const [searchDestination, setSearchDestination] = useState("");
  
  // Fetch available rides
  const { data: rides, isLoading, error } = useQuery<Ride[]>({
    queryKey: ["/api/rides"],
  });
  
  // Handler for find ride button
  const handleFindRide = () => {
    if (!searchDestination.trim()) {
      toast({
        title: "Please enter a destination",
        description: "Enter where you want to go to search for rides.",
        variant: "destructive",
      });
      return;
    }
    
    toast({
      title: "Searching for rides",
      description: `Looking for rides to ${searchDestination}...`,
    });
    
    // In a real app, this would filter rides by destination
    // For now, we'll just scroll down to the rides section
    document.getElementById("rides-section")?.scrollIntoView({ behavior: "smooth" });
  };
  
  // Handler for offer ride button
  const handleOfferRide = () => {
    navigate("/offer-ride");
  };
  
  // Filter function for rides (simulating search)
  const filteredRides = searchDestination.trim() 
    ? rides?.filter(ride => 
        ride.to.toLowerCase().includes(searchDestination.toLowerCase()) ||
        ride.from.toLowerCase().includes(searchDestination.toLowerCase())
      )
    : rides;

  return (
    <Layout>
      {/* Map Section */}
      <div className="relative h-[30vh] md:h-[40vh]">
        <MapView className="h-full w-full" />
        <div className="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center">
          <div className="bg-white rounded-lg shadow-lg p-4 w-[90%] max-w-md">
            <div className="flex items-center">
              <div className="bg-primary rounded-full p-2 text-white mr-3">
                <i className="fas fa-search"></i>
              </div>
              <Input
                placeholder="Where to?"
                className="flex-grow py-2 px-3"
                value={searchDestination}
                onChange={(e) => setSearchDestination(e.target.value)}
              />
            </div>
            <div className="grid grid-cols-2 gap-2 mt-3">
              <Button 
                onClick={handleFindRide}
                className="bg-primary hover:bg-indigo-700 text-white"
              >
                Find a Ride
              </Button>
              <Button 
                onClick={handleOfferRide}
                className="bg-secondary hover:bg-pink-600 text-white"
              >
                Offer a Ride
              </Button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Ride Listings */}
      <div id="rides-section" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold text-gray-900">Available Rides</h2>
          <div className="flex space-x-2">
            <Button variant="outline" size="sm" className="px-3 py-1.5 text-sm">
              <i className="fas fa-filter mr-1"></i> Filter
            </Button>
            <Button variant="outline" size="sm" className="px-3 py-1.5 text-sm">
              <i className="fas fa-sort mr-1"></i> Sort
            </Button>
          </div>
        </div>
        
        {isLoading ? (
          <div className="flex justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : error ? (
          <div className="text-center py-8">
            <p className="text-red-500">Error loading rides. Please try again.</p>
            <Button
              variant="outline"
              className="mt-2"
              onClick={() => window.location.reload()}
            >
              Refresh
            </Button>
          </div>
        ) : filteredRides && filteredRides.length > 0 ? (
          filteredRides.map((ride) => (
            <RideCard
              key={ride.id}
              ride={ride}
              onChatClick={() => {
                toast({
                  title: "Chat feature",
                  description: "Chat feature will be available soon.",
                });
              }}
            />
          ))
        ) : (
          <div className="text-center py-8">
            <p className="text-gray-500">No rides available{searchDestination ? ` for "${searchDestination}"` : ''}</p>
            <Button
              variant="link"
              className="mt-2 text-primary"
              onClick={() => window.location.reload()}
            >
              Refresh
            </Button>
          </div>
        )}
      </div>
    </Layout>
  );
}
