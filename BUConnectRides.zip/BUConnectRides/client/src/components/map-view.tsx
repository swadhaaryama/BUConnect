import { useEffect, useRef } from 'react';
import L from 'leaflet';

type MapViewProps = {
  className?: string;
  center?: [number, number];
  zoom?: number;
  markers?: Array<{
    position: [number, number];
    popup?: string;
  }>;
  routes?: Array<{
    points: Array<[number, number]>;
    color?: string;
  }>;
};

export default function MapView({
  className = '',
  center = [28.4595, 77.5500], // Default to Greater Noida coordinates
  zoom = 12,
  markers = [],
  routes = [],
}: MapViewProps) {
  const mapRef = useRef<L.Map | null>(null);
  const mapContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!mapContainerRef.current) return;

    // Initialize map if it doesn't exist
    if (!mapRef.current) {
      mapRef.current = L.map(mapContainerRef.current).setView(center, zoom);

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        maxZoom: 19,
      }).addTo(mapRef.current);
    } else {
      mapRef.current.setView(center, zoom);
    }

    // Clear existing markers and routes
    mapRef.current.eachLayer((layer) => {
      if (layer instanceof L.Marker || layer instanceof L.Polyline) {
        mapRef.current?.removeLayer(layer);
      }
    });

    // Add markers
    markers.forEach(marker => {
      const mapMarker = L.marker(marker.position).addTo(mapRef.current!);
      if (marker.popup) {
        mapMarker.bindPopup(marker.popup);
      }
    });

    // Add routes
    routes.forEach(route => {
      L.polyline(route.points, {
        color: route.color || '#4F46E5',
        weight: 5,
        opacity: 0.7,
      }).addTo(mapRef.current!);
    });

    // Clean up on unmount
    return () => {
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
    };
  }, [center, zoom, markers, routes]);

  return (
    <div 
      ref={mapContainerRef} 
      className={`${className} bg-gray-100`}
      style={{ minHeight: '200px' }}
    />
  );
}
