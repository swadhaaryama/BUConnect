import { Ride, User } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

type RideCardProps = {
  ride: Ride;
  driver?: User;
  isBooking?: boolean;
  status?: string;
  bookingId?: number;
  onChatClick?: () => void;
  onRateClick?: () => void;
};

export default function RideCard({
  ride,
  driver,
  isBooking = false,
  status,
  bookingId,
  onChatClick,
  onRateClick,
}: RideCardProps) {
  const { toast } = useToast();

  // Book ride mutation
  const bookRideMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/bookings", { rideId: ride.id });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/rides"] });
      queryClient.invalidateQueries({ queryKey: ["/api/bookings/passenger"] });
      toast({
        title: "Booking confirmed",
        description: "You've successfully booked a seat on this ride.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Booking failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Cancel booking mutation
  const cancelBookingMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("PATCH", `/api/bookings/${bookingId}/cancel`);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bookings/passenger"] });
      toast({
        title: "Booking cancelled",
        description: "Your booking has been cancelled.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Cancellation failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return (
    <div className={`bg-white rounded-xl shadow-sm mb-4 overflow-hidden ${isBooking && status === "confirmed" ? "border-l-4 border-primary" : ""}`}>
      <div className="p-4">
        <div className="flex items-start">
          {driver?.profilePicture ? (
            <img 
              src={driver.profilePicture} 
              alt={`${driver.name}'s profile`} 
              className="w-12 h-12 rounded-full object-cover"
            />
          ) : (
            <div className="w-12 h-12 rounded-full bg-gray-200 flex items-center justify-center">
              <span className="text-sm text-gray-500 font-medium">
                {driver?.name?.substring(0, 2).toUpperCase()}
              </span>
            </div>
          )}
          <div className="ml-3 flex-grow">
            <div className="flex justify-between">
              <h3 className="font-semibold text-gray-900">{driver?.name || "Driver"}</h3>
              {isBooking ? (
                <span className={`${status === "confirmed" ? "bg-primary bg-opacity-10 text-primary" : "bg-success bg-opacity-10 text-success"} text-xs font-medium px-2.5 py-0.5 rounded-full`}>
                  {status === "confirmed" ? "Confirmed" : "Completed"}
                </span>
              ) : (
                <div className="flex items-center text-sm text-gray-500">
                  <i className="fas fa-star text-yellow-400 mr-1"></i>
                  <span>{driver?.rating || 4.5}</span>
                </div>
              )}
            </div>
            <div className="flex items-center text-sm text-gray-500 mt-1">
              <i className="fas fa-car mr-1"></i>
              <span>{driver?.vehicle || "Car"} • {driver?.vehicleColor || "Color"}{driver?.vehicleNumber ? ` • ${driver.vehicleNumber}` : ""}</span>
            </div>
          </div>
        </div>
        <div className="mt-4 grid grid-cols-[auto_1fr] gap-x-3">
          <div className="flex flex-col items-center">
            <div className="w-3 h-3 rounded-full bg-green-500"></div>
            <div className="w-0.5 h-10 bg-gray-300"></div>
            <div className="w-3 h-3 rounded-full bg-red-500"></div>
          </div>
          <div className="space-y-3">
            <div>
              <p className="text-sm font-medium text-gray-700">{ride.from}</p>
              <p className="text-xs text-gray-500">Departure: {ride.departureDate}, {ride.departureTime}</p>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-700">{ride.to}</p>
              <p className="text-xs text-gray-500">Est. arrival: {getEstimatedArrival(ride.departureTime)}</p>
            </div>
          </div>
        </div>
        <div className="mt-4 flex justify-between items-center">
          <div>
            <span className="font-semibold text-gray-900">₹{ride.price}</span>
            <span className="text-sm text-gray-500">{isBooking ? " paid" : "/person"}</span>
          </div>
          <div className="flex space-x-2">
            <Button
              variant="outline"
              size="sm"
              className="px-3 py-1.5 rounded-full"
              onClick={onChatClick}
            >
              <i className="fas fa-comment mr-1"></i> Chat
            </Button>
            
            {isBooking ? (
              status === "confirmed" ? (
                <Button
                  variant="destructive"
                  size="sm"
                  className="px-3 py-1.5 rounded-full"
                  onClick={() => cancelBookingMutation.mutate()}
                  disabled={cancelBookingMutation.isPending}
                >
                  {cancelBookingMutation.isPending ? (
                    <>
                      <i className="fas fa-spinner fa-spin mr-1"></i> Cancelling
                    </>
                  ) : (
                    "Cancel"
                  )}
                </Button>
              ) : (
                <Button
                  variant="default"
                  size="sm"
                  className="px-3 py-1.5 rounded-full"
                  onClick={onRateClick}
                >
                  <i className="fas fa-star mr-1"></i> Rate
                </Button>
              )
            ) : (
              <Button
                variant="default"
                size="sm"
                className="px-3 py-1.5 rounded-full"
                onClick={() => bookRideMutation.mutate()}
                disabled={bookRideMutation.isPending || ride.availableSeats <= 0}
              >
                {bookRideMutation.isPending ? (
                  <>
                    <i className="fas fa-spinner fa-spin mr-1"></i> Booking
                  </>
                ) : (
                  "Book Seat"
                )}
              </Button>
            )}
          </div>
        </div>
        {ride.notes && (
          <div className="mt-3 text-sm text-gray-500">
            <i className="fas fa-info-circle mr-1"></i> {ride.notes}
          </div>
        )}
      </div>
    </div>
  );
}

// Helper function to calculate estimated arrival time based on departure time
function getEstimatedArrival(departureTime: string): string {
  try {
    const [hours, minutes] = departureTime.split(':').map(Number);
    let arrivalHours = hours + 1; // Simple estimate: add 1 hour to departure
    let arrivalMinutes = minutes;
    
    if (arrivalHours >= 24) {
      arrivalHours -= 24;
    }
    
    return `${arrivalHours.toString().padStart(2, '0')}:${arrivalMinutes.toString().padStart(2, '0')}`;
  } catch (error) {
    return departureTime;
  }
}
