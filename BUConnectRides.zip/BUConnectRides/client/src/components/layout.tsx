import { ReactNode, useState } from 'react';
import { useLocation, Link } from 'wouter';
import { useAuth } from '@/hooks/use-auth';

type NavItemProps = {
  icon: string;
  label: string;
  path: string;
  active: boolean;
  onClick: () => void;
};

const NavItem = ({ icon, label, path, active, onClick }: NavItemProps) => (
  <Link 
    href={path} 
    onClick={onClick}
    className={`flex flex-col items-center justify-center ${active ? 'text-primary' : 'text-gray-500'}`}
  >
    <i className={`${icon} text-lg`}></i>
    <span className="text-xs mt-1">{label}</span>
  </Link>
);

export default function Layout({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const { user } = useAuth();
  
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .substring(0, 2);
  };

  return (
    <div className="bg-light min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center">
            <svg className="h-8 w-8 text-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <h1 className="ml-2 text-xl font-semibold text-gray-900">BUConnect</h1>
          </div>
          <Link href="/profile">
            <a className="flex items-center justify-center w-10 h-10 rounded-full bg-gray-200 text-gray-700">
              <span className="text-sm font-medium">
                {user?.name ? getInitials(user.name) : ''}
              </span>
            </a>
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-grow pb-16">
        {children}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 w-full bg-white border-t border-gray-200 shadow-lg">
        <div className="grid grid-cols-5 h-16">
          <NavItem 
            icon="fas fa-home" 
            label="Home" 
            path="/" 
            active={location === '/'} 
            onClick={() => {}}
          />
          <NavItem 
            icon="fas fa-car-side" 
            label="Offer" 
            path="/offer-ride" 
            active={location === '/offer-ride'} 
            onClick={() => {}}
          />
          <NavItem 
            icon="fas fa-ticket-alt" 
            label="Bookings" 
            path="/bookings" 
            active={location === '/bookings'} 
            onClick={() => {}}
          />
          <NavItem 
            icon="fas fa-comment-alt" 
            label="Messages" 
            path="/messages" 
            active={location === '/messages'} 
            onClick={() => {}}
          />
          <NavItem 
            icon="fas fa-user" 
            label="Profile" 
            path="/profile" 
            active={location === '/profile'} 
            onClick={() => {}}
          />
        </div>
      </nav>
    </div>
  );
}
