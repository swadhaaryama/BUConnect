import { User } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";

type MessageCardProps = {
  id: number;
  partner: User;
  lastMessage: string;
  timestamp: Date;
  unread: boolean;
  onClick: () => void;
};

export default function MessageCard({
  id,
  partner,
  lastMessage,
  timestamp,
  unread,
  onClick,
}: MessageCardProps) {
  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden mb-4">
      <button 
        className="block p-4 w-full text-left hover:bg-gray-50 transition"
        onClick={onClick}
      >
        <div className="flex items-center">
          {partner.profilePicture ? (
            <img 
              src={partner.profilePicture} 
              alt={`${partner.name}'s profile`} 
              className="w-12 h-12 rounded-full object-cover"
            />
          ) : (
            <div className="w-12 h-12 rounded-full bg-gray-200 flex items-center justify-center">
              <span className="text-sm text-gray-500 font-medium">
                {partner.name.substring(0, 2).toUpperCase()}
              </span>
            </div>
          )}
          <div className="ml-3 flex-grow">
            <div className="flex justify-between">
              <h3 className="font-semibold text-gray-900">{partner.name}</h3>
              <span className="text-xs text-gray-500">
                {formatDistanceToNow(timestamp, { addSuffix: true })}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <p className="text-sm text-gray-500 truncate pr-4">{lastMessage}</p>
              {unread && <span className="bg-primary rounded-full w-2 h-2"></span>}
            </div>
          </div>
        </div>
      </button>
    </div>
  );
}
